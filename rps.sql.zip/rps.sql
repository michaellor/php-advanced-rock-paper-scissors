--
-- Database: `rps`
--
CREATE DATABASE IF NOT EXISTS `rps` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `rps`;

-- --------------------------------------------------------

--
-- Table structure for table `matches`
--

CREATE TABLE `matches` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `player_one_id` int(11) DEFAULT NULL,
  `player_one_score` int(11) DEFAULT NULL,
  `player_two_id` int(11) DEFAULT NULL,
  `player_two_score` int(11) DEFAULT NULL,
  `winner_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `matches`
--

INSERT INTO `matches` (`id`, `player_one_id`, `player_one_score`, `player_two_id`, `player_two_score`, `winner_id`) VALUES
(26, 1, 5, 4, 4, 4),
(27, 1, 0, -1, 0, 0),
(28, 1, 0, -1, 0, 0),
(29, 1, 2, 2, 0, 1),
(30, 1, 0, 3, 0, 0),
(31, 1, 2, 3, 4, 1),
(32, 1, 0, 2, 3, 2),
(33, 1, 0, 3, 2, 3),
(34, 1, 0, 2, 0, 0),
(35, 1, 2, 2, 0, 1),
(36, 1, 0, 2, 0, 0),
(37, 1, 0, -1, 0, 0),
(38, 1, 0, -1, 0, 0),
(39, 1, 0, -1, 0, 0),
(40, 1, 2, -1, 3, -1),
(41, 1, 0, 3, 0, 0),
(42, 1, 0, 3, 0, 0),
(43, 0, 0, 0, 0, 0),
(44, 10, 1, 0, 2, 0),
(45, 10, 2, 0, 0, 10),
(46, 10, 3, 0, 2, 10),
(47, 10, 0, 0, 2, 0),
(48, 10, 3, 0, 4, 0),
(49, 10, 4, 0, 4, 0),
(50, 10, 4, 0, 4, 0),
(51, 10, 4, 0, 2, 10),
(52, 10, 4, 0, 3, 10),
(53, 10, 3, 0, 4, 0),
(54, 0, 0, 0, 0, 0),
(55, 0, 0, 0, 0, 0),
(56, 0, 0, 0, 0, 0),
(57, 0, 0, 0, 0, 0),
(58, 0, 0, 0, 0, 0),
(59, 0, 0, 0, 0, 0),
(60, 12, 1, 0, 0, 12),
(61, 12, 0, 0, 1, 0),
(62, 12, 1, 0, 0, 12),
(63, 12, 1, 0, 2, 0),
(64, 12, 0, 0, 2, 0),
(65, 12, 0, 0, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`id`, `name`, `password`) VALUES
(0, 'Computer', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rounds`
--

CREATE TABLE `rounds` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `player_one_id` int(11) DEFAULT NULL,
  `player_one_choice` varchar(255) DEFAULT NULL,
  `player_two_id` int(11) DEFAULT NULL,
  `player_two_choice` varchar(255) DEFAULT NULL,
  `winner_id` int(11) DEFAULT NULL,
  `match_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `matches`
--
ALTER TABLE `matches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `rounds`
--
ALTER TABLE `rounds`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `matches`
--
ALTER TABLE `matches`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `rounds`
--
ALTER TABLE `rounds`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=715;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
